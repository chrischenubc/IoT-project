package com.github.nkzawa.socketio.client;

/**
 * Acknowledgement.
 */
public interface Ack {

    public void call(Object... args);

}

